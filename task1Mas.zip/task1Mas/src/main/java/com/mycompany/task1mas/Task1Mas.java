/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.task1mas;

/**
 *
 * @author Егор
 */
public class Task1Mas {

    public static void main(String[] args) {
        
        int iMas1 [];
        iMas1 = new int [1000]; 
        int i;
        for ( i=0;i<iMas1.length;i++){
            iMas1 [i] = (int) (Math.random()*101);
        }
        
        
        for ( i=0;i<iMas1.length-1;i++){
            for (int j=i+1;j<iMas1.length;j++){
                int iBuf = iMas1[i] ;
                if (iMas1[i]> iMas1[j]){
                    iMas1[i] = iMas1[j];
                    iMas1[j] = iBuf;
                }
                
                
                
            }
            System.out.println(iMas1[i]);
        }
        
        
        System.out.println("Hello World!");
    }
}
