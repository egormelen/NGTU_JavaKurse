/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.snakegame;

/**
 *
 * @author Egor
 */
public class SnakeGame {

    public static void main(String[] args) {
        MainWindow NJF = new MainWindow();
        NJF.setVisible(true);
        NJF.setTitle("Snake");
        
        
        GameField gf = new GameField();
        gf.setVisible(true);
        
    }
}
