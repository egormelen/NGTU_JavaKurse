/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hw38notepad;

/**
 *
 * @author Egor
 */
public class HW38notepad {

    public static void main(String[] args) {
        JFramePad NJF = new JFramePad();
        NJF.setVisible(true);
        NJF.setTitle("Notepad");
    }
}
