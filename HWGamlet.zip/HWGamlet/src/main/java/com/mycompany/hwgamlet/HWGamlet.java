/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hwgamlet;

import java.util.StringTokenizer;

/**
 *
 * @author Egor
 */
public class HWGamlet {

    public static void main(String[] args) {
        String sText= "William Shakespeare (baptised 26 April 1564 – died 23 April 1616) was an English poet and playwright, widely regarded as the greatest writer in the English language and the world's pre-eminent dramatist. He is often called England's national poet and the \"Bard of Avon\" (or simply \"The Bard\"). His surviving works consist of 38 plays, 154 sonnets, two long narrative poems, and several other poems. His plays have been translated into every major living language, and are performed more often than those of any other playwright. Shakespeare was born and raised in Stratford-upon-Avon. At the age of 18 he married Anne Hathaway, who bore him three children: Susanna, and twins Hamnet and Judith. Between 1585 and 1592 he began a successful career in London as an actor, writer, and part owner of the playing company the Lord Chamberlain's Men, later known as the King's Men. He appears to have retired to Stratford around 1613, where he died three years later. Few records of Shakespeare's private life survive, and there has been considerable speculation about such matters as his sexuality, religious beliefs, and whether the works attributed to him were written by others. Shakespeare produced most of his known work between 1590 and 1613. His early plays were mainly comedies and histories, genres he raised to the peak of sophistication and artistry by the end of the sixteenth century. Next he wrote mainly tragedies until about 1608, including Hamlet, King Lear, and Macbeth, considered some of the finest examples in the English language. In his last phase, he wrote tragicomedies, also known as romances, and collaborated with other playwrights. Many of his plays were published in editions of varying quality and accuracy during his lifetime, and in 1623 two of his former theatrical colleagues published the First Folio, a collected edition of his dramatic works that included all but two of the plays now recognised as Shakespeare's. Shakespeare was a respected poet and playwright in his own day, but his reputation did not rise to its present heights until the nineteenth century. The Romantics, in particular, acclaimed Shakespeare's genius, and the Victorians hero-worshipped Shakespeare with a reverence that George Bernard Shaw called \"bardolatry\". In the twentieth century, his work was repeatedly adopted and rediscovered by new movements in scholarship and performance. His plays remain highly popular today and are consistently performed and reinterpreted in diverse cultural and political contexts throughout the world. Source: Wikipedia";
        //String sText="aaaaaAAAA";
        int count =0;
        boolean flag = true;
        
        for (int i = 0; i < sText.length(); i++) {
            String s = sText.substring(i, i+1);
            if (s.equalsIgnoreCase("a")){
                count ++;   
            }
        }
        System.out.println(count);
        
        sText= "William Shakespeare (baptised 26 April 1564 – died 23 April 1616) was an English poet and playwright, widely regarded as the greatest writer in the English language and the world's pre-eminent dramatist. He is often called England's national poet and the \"Bard of Avon\" (or simply \"The Bard\"). His surviving works consist of 38 plays, 154 sonnets, two long narrative poems, and several other poems. His plays have been translated into every major living language, and are performed more often than those of any other playwright. Shakespeare was born and raised in Stratford-upon-Avon. At the age of 18 he married Anne Hathaway, who bore him three children: Susanna, and twins Hamnet and Judith. Between 1585 and 1592 he began a successful career in London as an actor, writer, and part owner of the playing company the Lord Chamberlain's Men, later known as the King's Men. He appears to have retired to Stratford around 1613, where he died three years later. Few records of Shakespeare's private life survive, and there has been considerable speculation about such matters as his sexuality, religious beliefs, and whether the works attributed to him were written by others. Shakespeare produced most of his known work between 1590 and 1613. His early plays were mainly comedies and histories, genres he raised to the peak of sophistication and artistry by the end of the sixteenth century. Next he wrote mainly tragedies until about 1608, including Hamlet, King Lear, and Macbeth, considered some of the finest examples in the English language. In his last phase, he wrote tragicomedies, also known as romances, and collaborated with other playwrights. Many of his plays were published in editions of varying quality and accuracy during his lifetime, and in 1623 two of his former theatrical colleagues published the First Folio, a collected edition of his dramatic works that included all but two of the plays now recognised as Shakespeare's. Shakespeare was a respected poet and playwright in his own day, but his reputation did not rise to its present heights until the nineteenth century. The Romantics, in particular, acclaimed Shakespeare's genius, and the Victorians hero-worshipped Shakespeare with a reverence that George Bernard Shaw called \"bardolatry\". In the twentieth century, his work was repeatedly adopted and rediscovered by new movements in scholarship and performance. His plays remain highly popular today and are consistently performed and reinterpreted in diverse cultural and political contexts throughout the world. Source: Wikipedia";
     
        StringTokenizer stObj = new StringTokenizer(sText,"aA");
        System.out.println(""+ stObj.countTokens());
        
        }



}


