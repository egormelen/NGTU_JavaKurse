/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.potokihw;

import static com.mycompany.potokihw.PotokiHW.mas4;


/**
 *
 * @author Egor
 */
public class secondThread extends Thread {
   
    @Override
    public void run() {
        
        for (int i = 0; i < mas4.length - 1; i++) {
            for (int j = i+1 ;j < mas4.length;j++ ){
                if (mas4[i]> mas4[j]){
                    int buf = mas4[i];
                    mas4[i]= mas4[j];
                    mas4[j]= buf;
                    
                }
            } 
        }
        
    }
   
}

