/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.potokihw;

/**
 *
 * @author Egor
 */
public class PotokiHW {
public static volatile int[] mas4;
public static volatile int m;


    public static void main(String[] args) throws InterruptedException {
        
        int[] mas1, mas2, mas3 ;
        mas1 = new int[100000];
        mas2 = new int[100000];
        mas3 = new int[100000];
        mas4 = new int[100000];
        
        for (int i = 0; i < mas1.length; i++) {
             mas1[i] = ((int)(Math.random()*100000) ); 
             mas3[i] = mas1[i];
        }
        
        for (int i = 0; i < mas2.length; i++) {
             mas2[i] = ((int)(Math.random()*100000) ); 
             mas4[i] = mas2[i];
        }
        
        long l1 = System.currentTimeMillis();
        
        for (int i = 0; i < mas1.length - 1; i++) {
            for (int j = i+1 ;j < mas1.length;j++ ){
                if (mas1[i]> mas1[j]){
                    int buf = mas1[i];
                    mas1[i]= mas1[j];
                    mas1[j]= buf;
                }
            } 
        }
        
        for (int i = 0; i < mas2.length - 1; i++) {
            for (int j = i+1 ;j < mas2.length;j++ ){
                if (mas2[i]> mas2[j]){
                    int buf = mas2[i];
                    mas2[i]= mas2[j];
                    mas2[j]= buf;
                }
            } 
        }
        long l2 = System.currentTimeMillis();
        
        secondThread objST = new secondThread();
        objST.start();
        
        
        for (int i = 0; i < mas3.length - 1; i++) {
            for (int j = i+1 ;j < mas3.length;j++ ){
                if (mas3[i]> mas3[j]){
                    int buf = mas3[i];
                    mas3[i]= mas3[j];
                    mas3[j]= buf;
                }
            } 
        }
    objST.join();    
    long l3 = System.currentTimeMillis();
        System.out.println(l2-l1);
        System.out.println(l3-l2);
        
        
        
    }
}
