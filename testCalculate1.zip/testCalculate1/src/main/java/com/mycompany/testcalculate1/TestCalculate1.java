/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testcalculate1;

/**
 *
 * @author Егор
 */
public class TestCalculate1 {

    public static void main(String[] args) {
        NewJFrame NJF = new NewJFrame();
        NJF.setVisible(true);
        NJF.setTitle("megaProg");
    }
}
