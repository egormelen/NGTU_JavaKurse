/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hw_db;

/**
 *
 * @author Egor
 */
public class HW_DB {

    public static void main(String[] args) {
        JFrameDB JF = new JFrameDB();
        JF.setVisible(true);
        
    }
}
